#pragma once

namespace vscode
{
	enum class state {
		birth = 1,
		initialized = 2,
		stepping = 3,
		running = 4,
		terminated = 5,
	};
}
